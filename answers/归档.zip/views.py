# coding=utf-8
from django.shortcuts import render
# from django.http import HttpResponse
from get_key import inaction,inscene,inask,getv,outbad
from scean import scenelib
from corpus_segment import CorpusSegement
from chatbot_integration import tmp_a
import codecs
from tupu.MatchOnline import Match
from models import Pair
from django.shortcuts import render_to_response
from django.http import HttpResponse,JsonResponse
seg=CorpusSegement()

ab=tmp_a()
from django import forms
from models import User
class UserForm(forms.Form):
    username = forms.CharField(label='用户名',max_length=50)
    password = forms.CharField(label='密  码',widget=forms.PasswordInput())
    email = forms.EmailField(label='邮  箱')

def regist(request):
    if request.method == 'POST':
        userform = UserForm(request.POST)
        if userform.is_valid():
            username = userform.cleaned_data['username']
            password = userform.cleaned_data['password']
            email = userform.cleaned_data['email']
            User.objects.create(username=username,password=password,email=email)
            # User.save()

            return HttpResponse('注册成功!')
    else:
        userform = UserForm()
    return render_to_response('regist.html',{'userform':userform})

def login(request):
    if request.method == 'POST':
        userform = UserForm(request.POST)
        if userform.is_valid():
            username = userform.cleaned_data['username']
            password = userform.cleaned_data['password']

            user = User.objects.filter(username__exact=username,password__exact=password)

            if user:
                return render_to_response('ichat.html',{'userform':userform})
            else:
                return HttpResponse('用户名或密码错误,请重新登录')

    else:
        userform = UserForm()
    return render_to_response('login.html',{'userform':userform})

def answer(line):
    result = []
    ans='!'
    if len(line) > 0:
        line1 = line
        line1 = line1.encode('utf-8')
        ab.predict(line1, result)
        # print('&&&', line, '+', type(line))
        line2 = ' '.join(seg.single_segment(line, hasOrigin=True))
        # print('***', line2)
        dl = line2.split('####')
        for sc in scenelib:
            if inscene(dl[0], sc):
                # out.append(dl[1].strip() + getv(dl[0]))
                if inask(dl[0], sc):
                    if inaction(dl[0], sc):
                        if outbad(dl[0], sc):
                            result.append(sc.ans)
        if u'宽带' in line:
            line3 = line
            kd = Match(line3)
            for i in kd:
                result.append(u'图谱结果：' + i)

        if len(result) == 0:
            ans = '^_^'
        else:
            ans = '\n'.join(result)
    return ans


# Create your views here.
def predict(request):
    input=''
    line=''
    user_list=[]
    fname='question_answers'
    if request.method=='POST':
        for i in request.POST:
            print i

        input=request.POST.get('username').split('\n')
        print input
        if request.META.has_key('HTTP_X_FORWARDED_FOR'):
            ip = request.META['HTTP_X_FORWARDED_FOR']
        else:
            ip = request.META['REMOTE_ADDR']
        if len(input)>1:
            if input[0][0]=='#':
                fname=input[0][1:]
                input=input[1:]

        # lines=input.split('\n')

        for line in input:
            ans=answer(line)
            if ans!='!':
                print line
                Pair.objects.create(ip=ip,question=line,answer=ans)
                user_list.append({'input':line,'ans':ans})
    # user_list = [
    #     {'input':'Question: '+line,'ans': 'Answer: '+ans}
    # ]

    # 计算当前日期和时间，并以 datetime.datetime 对象的形式保存为局部变量 now
    # now = datetime.datetime.now()

    # 构建Html响应，使用now替换占位符%s
    # html = "<html><body>It is now %s.</body></html>" % now
    # html = "<html><body>%d </body></html>" %a+b

    # 返回一个包含所生成响应的HttpResponse对象
    # return HttpResponse(html)
    # return render(request,'index1.html',{'data':user_list})
    if len(user_list)>0:
        return  JsonResponse({'input':user_list[0]['input'],'ans':user_list[0]['ans']})
        # return render(request,'ichat.html',{'input':user_list[0]['input'],'ans':user_list[0]['ans']})
    else:return render(request,'ichat.html')



def intro(request):
    return render(request,'intro.html')

def judge(request):
    if request.method=='POST':
        # req = simplejson.loads(request.body)
        # req = simplejson.loads(request.body)
        # print "bbbbb",req
        # weight=req['onType']
        weight=request.POST.get('opType')
        print weight,type(weight)
        # question=req['input']
        question=request.POST.get('ainput')
        print question
        pairs=Pair.objects.filter(question=question)
        pair=pairs[pairs.count()-1]
        pair.rate=int(float(weight))
        pair.save()
        return None

from django.http import StreamingHttpResponse

def file_download(request):
    # do something...
    def file_iterator(file_name, chunk_size=512):
        with open(file_name) as f:
            while True:
                c = f.read(chunk_size)
                if c:
                    yield c
                else:
                    break
    # print 1
    #
    the_file_name = "smartanswer.apk"
    response = StreamingHttpResponse(file_iterator('/Users/yangkang/PycharmProjects/smartdj/answers/static/app-release.apk'))
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Length'] = '1500'
    response['Content-Disposition'] = 'attachment;filename="{0}"'.format(the_file_name)
    # print 2

    return response